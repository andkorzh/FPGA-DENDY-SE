module RGB_OUT(
input clk,
input M2,
input nROMSEL,
input A13,
input A14,
input [5:0]PIX,
input [2:0]A,
input [2:0]DB,
input RnW,
input BLANK,
output [17:0]RGBo,
output EMP_R,
output EMP_G,
output EMP_B
);
wire nPPU_CE;
assign nPPU_CE = ~(M2 & nROMSEL & A13 & ~A14);
wire EWRITE;
assign EWRITE = ~( RnW | nPPU_CE ) & A[0] & ~A[1] & ~A[2];
assign EMP_R = EMP[0] ? 1'b0 : 1'hZ;
assign EMP_G = EMP[1] ? 1'b0 : 1'hZ;
assign EMP_B = EMP[2] ? 1'b0 : 1'hZ;
reg [2:0]EMP;
assign RGBo = BLANK ? 18'h0000 : RGB;
reg [17:0]RGB;
always @(posedge clk) begin
       if(EWRITE) EMP[2:0] <= DB[2:0];
        case (PIX)
       6'h0:  RGB <= 18'h18618;
       6'h1:  RGB <= 18'h00022;
       6'h2:  RGB <= 18'h080E6;
       6'h3:  RGB <= 18'h0E15E;
       6'h4:  RGB <= 18'h16158;
       6'h5:  RGB <= 18'h17004;
       6'h6:  RGB <= 18'h15100;
       6'h7:  RGB <= 18'h0F242;
       6'h8:  RGB <= 18'h08343;
       6'h9:  RGB <= 18'h03404;
       6'ha:  RGB <= 18'h06446;
       6'hb:  RGB <= 18'h003C8;
       6'hc:  RGB <= 18'h00316;
       6'hd:  RGB <= 18'h00000;
       6'he:  RGB <= 18'h00000;
       6'hf:  RGB <= 18'h00000;
       6'h10: RGB <= 18'h2BAEB;
       6'h11: RGB <= 18'h034F1;
       6'h12: RGB <= 18'h034F1;
       6'h13: RGB <= 18'h1A174;
       6'h14: RGB <= 18'h2416B;
       6'h15: RGB <= 18'h271D2;
       6'h16: RGB <= 18'h25341;
       6'h17: RGB <= 18'h1D501;
       6'h18: RGB <= 18'h17685;
       6'h19: RGB <= 18'h067C4;
       6'h1a: RGB <= 18'h05802;
       6'h1b: RGB <= 18'h05792;
       6'h1c: RGB <= 18'h076A4;
       6'h1d: RGB <= 18'h00000;
       6'h1e: RGB <= 18'h00000;
       6'h1f: RGB <= 18'h00000;
       6'h20: RGB <= 18'h3FFFF;
       6'h21: RGB <= 18'h199FF;
       6'h22: RGB <= 18'h2383F;
       6'h23: RGB <= 18'h2C6FF;
       6'h24: RGB <= 18'h376FD;
       6'h25: RGB <= 18'h3A72B;
       6'h26: RGB <= 18'h39896;
       6'h27: RGB <= 18'h33A09;
       6'h28: RGB <= 18'h2AB00;
       6'h29: RGB <= 18'h1DC00;
       6'h2a: RGB <= 18'h17CD4;
       6'h2b: RGB <= 18'h0DC64;
       6'h2c: RGB <= 18'h14C34;
       6'h2d: RGB <= 18'h11451;
       6'h2e: RGB <= 18'h00000;
       6'h2f: RGB <= 18'h00000;
       6'h30: RGB <= 18'h3FFFF;
       6'h31: RGB <= 18'h30D7F;
       6'h32: RGB <= 18'h33CFF;
       6'h33: RGB <= 18'h36C7F;
       6'h34: RGB <= 18'h3BC3F;
       6'h35: RGB <= 18'h3FC7A;
       6'h36: RGB <= 18'h3ED31;
       6'h37: RGB <= 18'h39CEA;
       6'h38: RGB <= 18'h37DE7;
       6'h39: RGB <= 18'h32E68;
       6'h3a: RGB <= 18'h30E6E;
       6'h3b: RGB <= 18'h2DEF2;
       6'h3c: RGB <= 18'h2EE7B;
       6'h3d: RGB <= 18'h2BAEB;
       6'h3e: RGB <= 18'h00000;
       6'h3f: RGB <= 18'h00000;
        endcase
                       end
endmodule
