/* Quartus II Version 11.0 Build 208 07/03/2011 Service Pack 1 SJ Web Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP1C3T100) Path("C:/altera/13.0sp1/FPGA_DENDY_SE/output_files/") File("FPGA_DENDY_SE.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
