## Generated SDC file "FPGA_DENDY.sdc"

## Copyright (C) 1991-2013 Altera Corporation
## Your use of Altera Corporation's design tools, logic functions 
## and other software and tools, and its AMPP partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Altera Program License 
## Subscription Agreement, Altera MegaCore Function License 
## Agreement, or other applicable license agreement, including, 
## without limitation, that your use is for the sole purpose of 
## programming logic devices manufactured by Altera and sold by 
## Altera or its authorized distributors.  Please refer to the 
## applicable agreement for further details.


## VENDOR  "Altera"
## PROGRAM "Quartus II"
## VERSION "Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Web Edition"

## DATE    "Thu Mar 19 19:02:41 2026"

##
## DEVICE  "EP1C3T100C8"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

derive_clock_uncertainty
derive_pll_clocks

create_clock -name {MCLK} -period 56.388 -waveform { 0.000 5.000 } [get_ports {MCLK}]




#**************************************************************
# Create Generated Clock
#**************************************************************

#create_generated_clock -name {inst62|altpll_component|pll|clk[0]~1} -source [get_pins {inst62|altpll_component|pll|inclk[1]}] -duty_cycle 50.000 -multiply_by 3 -divide_by 1 -master_clock {P_CLK} [get_pins {inst62|altpll_component|pll|clk[0]}] -add
#create_generated_clock -name {inst62|altpll_component|pll|clk[0]}   -source [get_pins {inst62|altpll_component|pll|inclk[0]}] -duty_cycle 50.000 -multiply_by 3 -divide_by 1 -master_clock {N_CLK} [get_pins {inst62|altpll_component|pll|clk[0]}] -add



#**************************************************************
# Set Clock Latency
#**************************************************************



#**************************************************************
# Set Clock Uncertainty
#**************************************************************



#**************************************************************
# Set Input Delay
#**************************************************************



#**************************************************************
# Set Output Delay
#**************************************************************



#**************************************************************
# Set Clock Groups
#**************************************************************



#**************************************************************
# Set False Path
#**************************************************************



#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************



#**************************************************************
# Set Minimum Delay
#**************************************************************



#**************************************************************
# Set Input Transition
#**************************************************************

