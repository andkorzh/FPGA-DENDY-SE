//NTSC_PAL composite video encoder
// Author HardWareMan
// Implementation of andkorzh
module CODER_NTSC_PAL(
//Clock
input Clk,           // Clock frequency 42.954 / 53.203 MHz
// Inputs
input SUBCLK,        // Subcarrier input
input BLANK,         // Blanking
input BURST,         // Color Subcarrier Sync Burst Output Mask
input SYNC,          // Composite sync input
input [5:0]PIX,      // Pixel input data
input [2:0]EMP,      // Emphasis B, G, R
input MODE,          // PAL/NTSC mode
input ODD,           // Even-odd scanline
// Outputs
output [6:0]COMPOSIT // Video DAC output
);
// Variables
reg [3:0]DIV;        // Clock frequency divider for obtaining color subcarrier
reg [12:1]PH;        // Color burst phase register
// Combinatorics
wire ODDM;
assign ODDM = ODD & MODE;

reg SUB;
// Emphasis
wire TINT;
assign TINT = (EMP[2] & PH[8]) | (EMP[1] & PH[4]) | (EMP[0] & PH[12]);
// The resulting signal
wire [6:0]DMUX;
assign DMUX[6:0] = (BURST) ?
                  (~ODDM) ?
                     PH[8] ? 7'h29 : 7'h0F
                  :
                     PH[6] ? 7'h29 : 7'h0F
               :
               (BLANK | (PIX[3] & PIX[2] & PIX[1])) ? 7'h16 :
                  (TINT) ?
                     (~PIX[5]) ?
                        (~PIX[4]) ?
                           (SUB) ? 7'h2B : 7'h0D
                        :
                           (SUB) ? 7'h43 : 7'h12
                     :
                        (~PIX[4]) ?
                           (SUB) ? 7'h60 : 7'h26
                        :
                           (SUB) ? 7'h60 : 7'h45
                  :
                     (~PIX[5]) ?
                        (~PIX[4]) ?
                           (SUB) ? 7'h36 : 7'h10
                        :
                           (SUB) ? 7'h54 : 7'h16
                     :
                        (~PIX[4]) ?
                           (SUB) ? 7'h78 : 7'h30
                        :
                           (SUB) ? 7'h78 : 7'h56;
assign COMPOSIT[6:0] = DMUX[6:0] & {7{SYNC}};
// Logics
always @(posedge Clk) begin
// Phase selector
            case ({ODDM,PIX[3:0]})
            5'h0:  SUB <= 1'b1;
            5'h1:  SUB <= PH[1];
            5'h2:  SUB <= PH[2];
            5'h3:  SUB <= PH[3];
            5'h4:  SUB <= PH[4];
            5'h5:  SUB <= PH[5];
            5'h6:  SUB <= PH[6];
            5'h7:  SUB <= PH[7];
            5'h8:  SUB <= PH[8];
            5'h9:  SUB <= PH[9];
            5'ha:  SUB <= PH[10];
            5'hb:  SUB <= PH[11];
            5'hc:  SUB <= PH[12];
            5'hd:  SUB <= 1'b0;
            5'he:  SUB <= 1'b0;
            5'hf:  SUB <= 1'b0;
            5'h10: SUB <= 1'b1;
            5'h11: SUB <= PH[4];
            5'h12: SUB <= PH[3];
            5'h13: SUB <= PH[2];
            5'h14: SUB <= PH[1];
            5'h15: SUB <= PH[12];
            5'h16: SUB <= PH[11];
            5'h17: SUB <= PH[10];
            5'h18: SUB <= PH[9];
            5'h19: SUB <= PH[8];
            5'h1a: SUB <= PH[7];
            5'h1b: SUB <= PH[6];
            5'h1c: SUB <= PH[5];
            5'h1d: SUB <= 1'b0;
            5'h1e: SUB <= 1'b0;
            5'h1f: SUB <= 1'b0;
            endcase


                      end
always @(negedge Clk) begin
   // Color burst phase register
   {PH[12:1]} <= {SUBCLK,PH[12:2]};
                       end
// End of module
endmodule